CREATE DATABASE covid19_project;
use covid19_project;
select * from final_covid_data;

# Q1 ) Find the number of corona patients who faced shortness of breath.
select * from final_covid_data
where shortness_of_breath="True";

# Q2.) Find the number of negative corona patients who have fever and sore_throat. 
select count(*) from final_covid_data
where Corona="negative"
and fever="True" and sore_throat="True";

# Q3.)Group the data by month and rank the number of positive cases.
-- select ROW_NUMBER() OVER (ORDER BY test_date desc) top from final_covid_data
-- where corona="Positive"
-- group by  DATE_FORMAT(Test_date, '%m');

-- Answer

select strftime('%m', date(Test_date)) as Month,
 count(*) as counts from (select*from final_covid_data
 where corona = 'positive')xyz GROUP BY Month order by counts desc;

-- select DATEPART(MONTH, Test_date) AS month from final_covid_data
-- where corona="Positive"
-- group by DATEPART(MONTH, Test_date);



# Q4.) Find the female negative corona patients who faced cough and headache.
select * from final_covid_data
where Gender = "female"
having corona="negative" and cough_symptoms="True" and headache="True";

# Q5.) How many elderly corona patients have faced breathing problems?
select * from final_covid_data
where Age_60_above="Yes" and corona="Positive"
having Shortness_of_breath="True";

# Q6.) Which three symptoms were more common among COVID positive patients?

select * from (
    select cough_symptoms , count(*) as cnt from final_covid_data where corona = 'positive' and cough_symptoms ='True'
    union all
    select  Fever, count(*) as cnt from final_covid_data where corona = 'positive' and Fever ='True'
    union all
    select  Sore_throat, count(*) as cnt from final_covid_data where corona = 'positive' and Sore_throat ='True'
    union all
    select  Shortness_of_breath, count(*) as cnt from final_covid_data where corona = 'positive' and Shortness_of_breath ='True'
    union all
select  Headache, count(*) as cnt from final_covid_data where corona = 'positive' and Headache ='True'
   ) xyz order by cnt desc



# Q7.) Which symptom was less common among COVID negative people?

select * from (
    select cough_symptoms , count(*) as cnt from final_covid_data where corona = 'negative' and cough_symptoms ='True'
    union all
    select  Fever, count(*) as cnt from final_covid_data where corona = 'negative' and Fever ='True'
    union all
    select  Sore_throat, count(*) as cnt from final_covid_data where corona = 'negative' and Sore_throat ='True'
    union all
    select  Shortness_of_breath, count(*) as cnt from final_covid_data where corona = 'negative' and Shortness_of_breath ='True'
    union all
    select  Headache, count(*) as cnt from final_covid_data where corona = 'negative' and Headache ='True'
  
    ) xyz order by cnt

#Q8.) What are the most common symptoms among COVID positive males whose known contact was abroad? 
    select cough_symptoms , count(*) as cnt from final_covid_data 
    where corona = 'positive' and cough_symptoms ='True' 
    and gender = 'male' and known_contact = 'Abroad'
    union all
    select  Fever, count(*) as cnt from final_covid_data 
    where corona = 'positive' and Fever ='True'
    and gender = 'male' and known_contact = 'Abroad'
    union all
    select  Sore_throat, count(*) as cnt from final_covid_data 
    where corona = 'positive' and Sore_throat ='True'
    and gender = 'male' and known_contact = 'Abroad'
    union all
    select  Shortness_of_breath, count(*) as cnt from final_covid_data 
    where corona = 'positive' and Shortness_of_breath ='True'
    and gender = 'male' and known_contact = 'Abroad'
    union all
    select  Headache, count(*) as cnt from final_covid_data
    where corona = 'positive' and Headache ='True'
    and gender = 'male' and known_contact = 'Abroad'